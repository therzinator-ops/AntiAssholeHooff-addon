------------------------------------------------------------
-- AntiAssholeHooff UI Panel
------------------------------------------------------------

SLASH_ANTIASSHOLEHOOFF1 = "/aah"
SlashCmdList["ANTIASSHOLEHOOFF"] = function()
    AntiAssholeHooffUI_Toggle()
end

------------------------------------------------------------
-- Helpers
------------------------------------------------------------

local function TitleCase(s)
    if not s then return s end
    return string.gsub(s, "^(%l)", string.upper)
end

local function ensureDB()
    AntiAssholeHooffDB = AntiAssholeHooffDB or {}
    AntiAssholeHooffDB.blacklist = AntiAssholeHooffDB.blacklist or {}
    AntiAssholeHooffDB.portalBlockSeconds = AntiAssholeHooffDB.portalBlockSeconds or 3
end

------------------------------------------------------------
-- Main Frame
------------------------------------------------------------

local f = CreateFrame("Frame", "AntiAssholeHooffUI", UIParent)
f:SetWidth(420)
f:SetHeight(320)
f:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
f:SetFrameStrata("DIALOG")
f:Hide()

f:SetBackdrop({
    bgFile   = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile     = true,
    tileSize = 32,
    edgeSize = 32,
    insets   = { left = 11, right = 12, top = 12, bottom = 11 }
})

------------------------------------------------------------
-- Title
------------------------------------------------------------

local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
title:SetPoint("TOP", 0, -15)
title:SetText("AntiAssholeHooff Options")

------------------------------------------------------------
-- Portal block duration
------------------------------------------------------------

local lbl = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
lbl:SetPoint("TOPLEFT", 20, -55)
lbl:SetText("Portal block duration (seconds):")

local secBox = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
secBox:SetWidth(40)
secBox:SetHeight(20)
secBox:SetPoint("LEFT", lbl, "RIGHT", 10, 0)
secBox:SetAutoFocus(false)
secBox:SetNumeric(true)

------------------------------------------------------------
-- Blacklist editor
------------------------------------------------------------

local blFrame = CreateFrame("Frame", "AntiAssholeHooffBlacklistFrame", f)
blFrame:SetWidth(380)
blFrame:SetHeight(180)
blFrame:SetPoint("TOPLEFT", 20, -100)

local blLbl = blFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
blLbl:SetPoint("TOPLEFT", 0, 0)
blLbl:SetText("Blacklist name:")

local blEdit = CreateFrame("EditBox", nil, blFrame, "InputBoxTemplate")
blEdit:SetWidth(140)
blEdit:SetHeight(20)
blEdit:SetPoint("LEFT", blLbl, "RIGHT", 10, 0)
blEdit:SetAutoFocus(false)

------------------------------------------------------------
-- Add/remove buttons
------------------------------------------------------------

local addBtn = CreateFrame("Button", nil, blFrame, "UIPanelButtonTemplate")
addBtn:SetWidth(60)
addBtn:SetHeight(22)
addBtn:SetPoint("LEFT", blEdit, "RIGHT", 5, 0)
addBtn:SetText("Add")

addBtn:SetScript("OnClick", function()
    ensureDB()
    local name = blEdit:GetText()
    if name and name ~= "" then
        local fixed = TitleCase(name)
        AntiAssholeHooffDB.blacklist[fixed] = true
        DEFAULT_CHAT_FRAME:AddMessage("|cffff5555Added to blacklist:|r " .. fixed)
        blEdit:SetText("")
        AntiAssholeHooffUI_RefreshList()
    end
end)

local delBtn = CreateFrame("Button", nil, blFrame, "UIPanelButtonTemplate")
delBtn:SetWidth(70)
delBtn:SetHeight(22)
delBtn:SetPoint("LEFT", addBtn, "RIGHT", 5, 0)
delBtn:SetText("Remove")

delBtn:SetScript("OnClick", function()
    ensureDB()
    local name = blEdit:GetText()
    if name and name ~= "" then
        local fixed = TitleCase(name)
        AntiAssholeHooffDB.blacklist[fixed] = nil
        DEFAULT_CHAT_FRAME:AddMessage("|cffff5555Removed from blacklist:|r " .. fixed)
        blEdit:SetText("")
        AntiAssholeHooffUI_RefreshList()
    end
end)

------------------------------------------------------------
-- Blacklist display
------------------------------------------------------------

local listBG = CreateFrame("Frame", "AntiAssholeHooffListBG", blFrame)
listBG:SetWidth(360)
listBG:SetHeight(120)
listBG:SetPoint("TOPLEFT", 0, -30)
listBG:SetBackdrop({ bgFile = "Interface\\ChatFrame\\ChatFrameBackground" })
listBG:SetBackdropColor(0, 0, 0, 0.30)

local listText = listBG:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
listText:SetPoint("TOPLEFT", 8, -8)
listText:SetJustifyH("LEFT")
listText:SetWidth(344)

------------------------------------------------------------
-- Refresh list
------------------------------------------------------------

function AntiAssholeHooffUI_RefreshList()
    ensureDB()
    local bl = AntiAssholeHooffDB.blacklist
    local names = {}
    for k in pairs(bl) do
        table.insert(names, k)
    end
    table.sort(names)

    -- avoid using '#' operator altogether to sidestep parser quirks
    if not next(names) then
        listText:SetText("(no names)")
        return
    end

    listText:SetText(table.concat(names, "\n"))
end

------------------------------------------------------------
-- Save & Close Buttons
------------------------------------------------------------

local saveBtn = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
saveBtn:SetWidth(80)
saveBtn:SetHeight(24)
saveBtn:SetPoint("BOTTOMRIGHT", -15, 15)
saveBtn:SetText("Save")

saveBtn:SetScript("OnClick", function()
    ensureDB()
    local sec = tonumber(secBox:GetText()) or 3
    AntiAssholeHooffDB.portalBlockSeconds = sec
    if AntiAssholeHooff_RefreshAfterSave then
        AntiAssholeHooff_RefreshAfterSave()
    end
    DEFAULT_CHAT_FRAME:AddMessage("|cffff5555AntiAssholeHooff:|r Settings saved.")
    f:Hide()
end)

local closeBtn = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
closeBtn:SetWidth(80)
closeBtn:SetHeight(24)
closeBtn:SetPoint("BOTTOMLEFT", 15, 15)
closeBtn:SetText("Close")

closeBtn:SetScript("OnClick", function()
    f:Hide()
end)

------------------------------------------------------------
-- Toggle UI
------------------------------------------------------------

function AntiAssholeHooffUI_Toggle()
    ensureDB()
    if AntiAssholeHooffUI:IsShown() then
        AntiAssholeHooffUI:Hide()
    else
        secBox:SetText(AntiAssholeHooffDB.portalBlockSeconds or 3)
        AntiAssholeHooffUI_RefreshList()
        AntiAssholeHooffUI:Show()
    end
end
