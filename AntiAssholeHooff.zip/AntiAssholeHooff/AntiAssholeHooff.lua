------------------------------------------------------------
-- AntiAssholeHooff core (TurtleWoW)
------------------------------------------------------------

AntiAssholeHooffDB = AntiAssholeHooffDB or {}

local defaults = {
    blacklist = {},
    portalBlockSeconds = 3,
}

------------------------------------------------------------
-- Helpers
------------------------------------------------------------

local function TitleCase(s)
    if not s then return s end
    return string.gsub(s, "^(%l)", string.upper)
end

local function isBad(name)
    if not name or not AntiAssholeHooffDB or not AntiAssholeHooffDB.blacklist then
        return false
    end
    return AntiAssholeHooffDB.blacklist[TitleCase(name)] == true
end

local function dprint(msg)
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage("|cffff5555AntiAssholeHooff:|r " .. tostring(msg))
    end
end

------------------------------------------------------------
-- DB init
------------------------------------------------------------

local function initDB()
    for k, v in pairs(defaults) do
        if AntiAssholeHooffDB[k] == nil then
            AntiAssholeHooffDB[k] = v
        end
    end
end

initDB()

------------------------------------------------------------
-- Proximity detection
------------------------------------------------------------

local function blacklistedNearby()
    -- raid
    for i = 1, 40 do
        local u = "raid" .. i
        if UnitExists(u) and isBad(UnitName(u)) then return true end
    end
    -- party
    for i = 1, 4 do
        local u = "party" .. i
        if UnitExists(u) and isBad(UnitName(u)) then return true end
    end
    -- ungrouped
    if UnitExists("target") and isBad(UnitName("target")) then return true end
    if UnitExists("mouseover") and isBad(UnitName("mouseover")) then return true end
    return false
end

------------------------------------------------------------
-- Overlay blocking system
------------------------------------------------------------

local overlay = CreateFrame("Frame", "AntiAssholeHooffOverlay", UIParent)
overlay:SetAllPoints(UIParent)
overlay:SetFrameStrata("FULLSCREEN_DIALOG")
overlay:Hide()
overlay:EnableMouse(false)

local alertText = overlay:CreateFontString(nil, "OVERLAY")
alertText:SetFont("Fonts\\FRIZQT__.TTF", 145, "OUTLINE")
alertText:SetPoint("CENTER", 0, 0)
alertText:SetText("|cffffda6aASSHOLE IN YOUR VICINITY, BLOCKING KARA PORTAL ACCESS!|r")
alertText:Hide()

local blockUntil = 0
local lastBlockEnd = 0
local BLOCK_COOLDOWN = 1.0

local function PlayThreatAlert()
    if PlaySound then
        PlaySound("PVPFlagTaken")
        PlaySound("RaidWarning")
    end
end

local function startBlock(duration)
    duration = tonumber(duration) or AntiAssholeHooffDB.portalBlockSeconds or 3
    if blacklistedNearby() then
        duration = duration + 3
    end

    blockUntil = GetTime() + duration
    overlay:EnableMouse(true)
    overlay:Show()
    alertText:Show()

    -- only play center-screen warning + sound
    PlayThreatAlert()
end

local upd = CreateFrame("Frame")
upd:SetScript("OnUpdate", function()
    if overlay:IsShown() and GetTime() >= blockUntil then
        overlay:EnableMouse(false)
        overlay:Hide()
        alertText:Hide()
        lastBlockEnd = GetTime()
    end
end)

------------------------------------------------------------
-- Tooltip detection (portal mouseover)
------------------------------------------------------------

local portalKeywords = { "Karazhan", "Kara", "Atiesh" }

local function isPortalTooltip(txt)
    if not txt then return false end
    for _, kw in ipairs(portalKeywords) do
        if string.find(txt, kw) then return true end
    end
    return false
end

local originalOnShow = GameTooltip:GetScript("OnShow")
GameTooltip:SetScript("OnShow", function()
    if overlay:IsShown() then
        if originalOnShow then originalOnShow() end
        return
    end

    if (GetTime() - lastBlockEnd) < BLOCK_COOLDOWN then
        if originalOnShow then originalOnShow() end
        return
    end

    local txt = GameTooltipTextLeft1 and GameTooltipTextLeft1:GetText()
    if txt and isPortalTooltip(txt) and blacklistedNearby() then
        startBlock()
    end

    if originalOnShow then originalOnShow() end
end)

------------------------------------------------------------
-- Chat message detection (Portal: Karazhan)
------------------------------------------------------------

local function matchPortal(msg)
    if type(msg) ~= "string" then return nil, nil end
    local who, dest

    who, dest = string.match(msg, "^(%S+) begins to cast [Pp]ortal:%s*(.+)$")
    if who and dest and string.find(dest, "Karazhan") then
        return TitleCase(who), "Karazhan"
    end

    who, dest = string.match(msg, "^(%S+) casts [Pp]ortal[:%s]+(.+)$")
    if who and dest and string.find(dest, "Karazhan") then
        return TitleCase(who), "Karazhan"
    end

    who, dest = string.match(msg, "^(%S+) opens a [Pp]ortal to%s+(.+)$")
    if who and dest and string.find(dest, "Karazhan") then
        return TitleCase(who), "Karazhan"
    end

    return nil, nil
end

------------------------------------------------------------
-- Event handler (no kidnap logic)
------------------------------------------------------------

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")

-- Portal chat messages
f:RegisterEvent("CHAT_MSG_SPELL_FRIENDLYPLAYER_DAMAGE")
f:RegisterEvent("CHAT_MSG_SPELL_FRIENDLYPLAYER_BUFF")
f:RegisterEvent("CHAT_MSG_SPELL_PARTY_BUFF")

f:SetScript("OnEvent", function()
    local e = event
    local msg = arg1

    if e == "PLAYER_LOGIN" then
        dprint("Loaded. Karazhan portal protection active.")
        return
    end

    if type(msg) ~= "string" then msg = "" end

    -- Portal detection only
    local who = matchPortal(msg)
    if who and isBad(who) then
        startBlock()
    end
end)

------------------------------------------------------------
-- Refresh after save (UI)
------------------------------------------------------------

function AntiAssholeHooff_RefreshAfterSave()
    overlay:EnableMouse(false)
    overlay:Hide()
    alertText:Hide()
    lastBlockEnd = GetTime()
end
